package com.developeralamin.musicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.VideoView;

public class VideoActivity extends AppCompatActivity {

    VideoView videoView;

    ProgressBar progressBar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        getSupportActionBar().hide();

        videoView = findViewById(R.id.videoView);

        progressBar = findViewById(R.id.progressBar);

        videoView.setMediaController(new MediaController(this));

        videoView.setVideoPath("https://firebasestorage.googleapis.com/v0/b/test-b6073.appspot.com/o/sub.mp4?alt=media&token=5915120b-8388-43e0-ab1d-8158107c5149");

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {

                mediaPlayer.start();

                progressBar.setVisibility(View.GONE);
            }
        });


        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                mediaPlayer.start();

                progressBar.setVisibility(View.GONE);
            }
        });

    }
}